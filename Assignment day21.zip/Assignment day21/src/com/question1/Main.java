package com.question1;

public class Main {

	public static void main(String[] args) {
		Calculate cal = new Calculate();
		cal.start();
	}
}
